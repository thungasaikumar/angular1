export class PlacingOrder{
    custid:number;
    custname:string;
    custaddress:string;
    custstate:string;
    phone:number;
    withindays:number;
    status:string;
    
    productid:number;
    name:string;
    brand:string;
    description:string;
    model:string;
    price:number;
    
    }