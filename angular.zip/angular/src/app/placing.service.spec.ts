import { TestBed } from '@angular/core/testing';

import { PlacingService } from './placing.service';

describe('PlacingService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PlacingService = TestBed.get(PlacingService);
    expect(service).toBeTruthy();
  });
});
